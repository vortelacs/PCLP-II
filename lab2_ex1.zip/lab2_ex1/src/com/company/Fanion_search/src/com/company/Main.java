package com.company;

import java.util.*;


class Main {
    
	public static void main (String[] args) throws java.lang.Exception {
	    
	    int n, m, i, j, s, ok=0;
	    
	    Scanner input= new Scanner(System.in);
	    System.out.print("Give the n size of array: ");
	    n=input.nextInt();
     System.out.print("Give the m size of array: ");  
	    m=input.nextInt();
	    int [][] arr=new int[n][m];
	    System.out.print("Give the numbers: \n");
	    for(i=0;i<n;i++) for(j=0;j<m;j++) arr[i][j]=input.nextInt();
	    
	    System.out.print("Give the number you want to find: ");
	    s=input.nextInt();
	    
	    for(i=0;i<n;i++) for(j=0;j<m;j++) if(arr[i][j]==s){
	        System.out.print("Number was found at index :"+ i +", "+j);
	        ok=1;
	        break;
	    }
	    if(ok==0) System.out.print("Number wasn't found");
        
     
	}
	
}